# This file is dual licensed under the terms of the Apache License, Version
# 2.0, and the BSD License. See the LICENSE file in the root of this repository
# for complete details.

from __future__ import annotations

__all__ = [
    "__version__",
    "__author__",
    "__copyright__",
]

__version__ = "42.0.0"


__author__ = "The Python Cryptographic Authority and individual contributors"
__copyright__ = f"Copyright 2013-2024 {__author__}"
