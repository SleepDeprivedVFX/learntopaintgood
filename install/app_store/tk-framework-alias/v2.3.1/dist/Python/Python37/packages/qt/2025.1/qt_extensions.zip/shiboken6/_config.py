shiboken_library_soversion = str(6.5)

version = "6.5.3"
version_info = (6, 5, 3, "", "")

__build_date__ = '2023-09-29T16:09:10+00:00'




__setup_py_package_version__ = '6.5.3'

